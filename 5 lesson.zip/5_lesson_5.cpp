#include<stdlib.h>
#include <stdio.h>
#include <iostream>
#include<math.h >


int main()
{
	/*
	�������� ������
	1. if( x1 > x2 && x1 < x3 || x1 < x2 && x1 > x3)
	{
	}
	
	2. ������ ������������� ����
	double ���
	
	4. 
	% 111

	5.
	��� ����� 
	�� ������� 60
	double ��� ����
	
	7.
	��������
	1999 10  
	2000  2
	0     4

	1999 10
	2000 12
	1     2
	
	1999 17 - ������������ ����
	
	1999 12
	1998  5 - ������������ ����
	
	2000 5
	2000 10
	
	
	
	int value1, value2, value3;
	printf("Enter the number1: ");
	scanf("%d", &value1);
	printf("Enter the number2: ");
	scanf("%d", &value2);
	printf("Enter the number3: ");
	scanf("%d", &value3);
	
	if(value1 > value2 && value1 < value3 || value1 < value2 && value1 > value3)
	{
		printf("value1 = %d", value1);
	}
	else
	{
		if(value2 > value1 && value2 < value3 || value2 < value1 && value2 > value3)
		{
			printf("value2 = %d", value2);
		}
		else
		{
			if(value3 > value1 && value3 < value2 || value2 < value1 && value2 > value3)
			{
				printf("value3 = %d", value3);
			}
		}
	}
	
	double km, ft, result;
	const double MET = 0.305;
	
	printf("Enter the number1: ");
	scanf("%lf", &km);
	printf("Enter the number2: ");
	scanf("%lf", &ft);
	
	result = ft * MET;
	km *= 1000;
	
	if(km < result)
	{
		printf("km %.2lf", km);
	}
	else
	{
		if(result < km)
		{
			printf("ft %.2lf", result);	
		}
		else
		{
			printf("km = ft %.2lf = %.2lf", km, result);
		}
	}*/
	
	int value1, value2;
	printf("Enter the number1: ");
	scanf("%d", &value1);
	printf("Enter the number2: ");
	scanf("%d", &value2);
	int dozens = 0, units = 0, sum_of_digits = 0, product_of_numbers = 0;
	dozens = value1 / 10;
	units = value1 % 10;
	sum_of_digits = dozens + units;
	if(value1 > 9 && value1 < 100)
	{
		int dozens = 0, units = 0, sum_of_digits = 0, product_of_numbers = 0;
		dozens = value1 / 10;
		units = value1 % 10;
		sum_of_digits = dozens + units;
		if(sum_of_digits > value2)
		{
			printf("value1 = %d", value1);
		}
		else
		{
			if(sum_of_digits < value2)
			{
				printf("value2 = %d", value2);
			}
			else
			{
				printf("value1 = value2 %d %d", value1, value2);	
			}
		}
	}
	else
	{
		printf("Error");
	}
	getchar();
	return 0;
}
